using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Parcial.Models;

namespace Parcial.Controllers
{
public class ContactoController : Controller
    {
         public IActionResult Contacto()
        {
            return View();
        }
    }
}